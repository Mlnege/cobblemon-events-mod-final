# CobbleDomes Datapack

코블몬 서버용 18타입 돔 경기장 데이터팩입니다.
이 팩은 **바닐라 데이터팩 + 함수 명령어** 방식이라 Cobblemon/Fabric/NeoForge 서버에서도 바로 넣어 쓸 수 있습니다.

## 설치
1. 압축 파일을 월드의 `datapacks` 폴더에 넣습니다.
2. 서버/월드를 열고 `/reload`
3. 돔 중심이 될 위치에서 `/function cobbledomes:install`
4. 같은 위치에서 `/function cobbledomes:build_all`

## 포함 내용
- 중앙 허브 1개
- 18개 타입 돔
- 타입별 색상/블록 테마
- 개별 생성 함수 (`/function cobbledomes:place_fire` 등)

## 주의
- 넓은 평지/슈퍼플랫에서 먼저 테스트하세요.
- 현재 버전은 **즉시 배치형 스타터 팩**입니다.
- 월드에디트 `.schem`처럼 예술형 수작업 맵은 아니고, 서버에서 바로 쓰기 쉬운 자동 생성형입니다.
- 큰 구조물이므로 백업 후 사용하세요.

## 타입 좌표(기준점 상대)
{
  "hub": [
    0,
    0
  ],
  "fire": [
    96,
    0
  ],
  "water": [
    -96,
    0
  ],
  "grass": [
    0,
    96
  ],
  "electric": [
    0,
    -96
  ],
  "ice": [
    96,
    96
  ],
  "rock": [
    -96,
    -96
  ],
  "psychic": [
    -96,
    96
  ],
  "ghost": [
    96,
    -96
  ],
  "dragon": [
    0,
    192
  ],
  "fairy": [
    192,
    0
  ],
  "dark": [
    -192,
    0
  ],
  "steel": [
    0,
    -192
  ],
  "ground": [
    192,
    96
  ],
  "bug": [
    -192,
    96
  ],
  "poison": [
    96,
    192
  ],
  "flying": [
    -96,
    192
  ],
  "fighting": [
    192,
    -96
  ],
  "normal": [
    -192,
    -96
  ]
}
