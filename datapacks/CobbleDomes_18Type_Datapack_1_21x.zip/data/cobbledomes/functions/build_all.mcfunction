tellraw @s [{"text":"[CobbleDomes] ","color":"gold"},{"text":"중앙 허브와 18개 타입 돔을 생성합니다. 큰 지형에 설치하세요.","color":"yellow"}]
function cobbledomes:build/hub
execute positioned ~96 ~ ~0 run function cobbledomes:build/types/fire
execute positioned ~-96 ~ ~0 run function cobbledomes:build/types/water
execute positioned ~0 ~ ~96 run function cobbledomes:build/types/grass
execute positioned ~0 ~ ~-96 run function cobbledomes:build/types/electric
execute positioned ~96 ~ ~96 run function cobbledomes:build/types/ice
execute positioned ~-96 ~ ~-96 run function cobbledomes:build/types/rock
execute positioned ~-96 ~ ~96 run function cobbledomes:build/types/psychic
execute positioned ~96 ~ ~-96 run function cobbledomes:build/types/ghost
execute positioned ~0 ~ ~192 run function cobbledomes:build/types/dragon
execute positioned ~192 ~ ~0 run function cobbledomes:build/types/fairy
execute positioned ~-192 ~ ~0 run function cobbledomes:build/types/dark
execute positioned ~0 ~ ~-192 run function cobbledomes:build/types/steel
execute positioned ~192 ~ ~96 run function cobbledomes:build/types/ground
execute positioned ~-192 ~ ~96 run function cobbledomes:build/types/bug
execute positioned ~96 ~ ~192 run function cobbledomes:build/types/poison
execute positioned ~-96 ~ ~192 run function cobbledomes:build/types/flying
execute positioned ~192 ~ ~-96 run function cobbledomes:build/types/fighting
execute positioned ~-192 ~ ~-96 run function cobbledomes:build/types/normal
tellraw @s [{"text":"[CobbleDomes] ","color":"gold"},{"text":"생성 완료.","color":"green"}]
