gamerule commandBlockOutput false
tellraw @s [{"text":"[CobbleDomes] ","color":"gold"},{"text":"현재 위치를 중앙 허브 기준점으로 사용합니다.","color":"aqua"}]
tellraw @s [{"text":"[CobbleDomes] ","color":"gold"},{"text":"/function cobbledomes:build_all 로 18타입 돔을 생성하세요.","color":"green"}]
