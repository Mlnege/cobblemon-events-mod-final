tellraw @a [{"text":"[CobbleDomes] ","color":"gold"},{"text":"데이터팩 로드 완료. /function cobbledomes:install 또는 /function cobbledomes:build_all 사용","color":"yellow"}]
