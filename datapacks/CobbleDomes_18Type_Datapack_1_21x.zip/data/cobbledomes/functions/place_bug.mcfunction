execute positioned ~-192 ~ ~96 run function cobbledomes:build/types/bug
