execute positioned ~-192 ~ ~0 run function cobbledomes:build/types/dark
