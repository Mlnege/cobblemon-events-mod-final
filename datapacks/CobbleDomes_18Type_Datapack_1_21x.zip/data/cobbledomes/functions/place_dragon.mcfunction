execute positioned ~0 ~ ~192 run function cobbledomes:build/types/dragon
