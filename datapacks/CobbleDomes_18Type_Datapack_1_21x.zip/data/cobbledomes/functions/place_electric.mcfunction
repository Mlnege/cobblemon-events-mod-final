execute positioned ~0 ~ ~-96 run function cobbledomes:build/types/electric
