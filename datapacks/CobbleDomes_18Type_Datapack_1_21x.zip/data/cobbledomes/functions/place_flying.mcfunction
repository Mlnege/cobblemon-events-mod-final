execute positioned ~-96 ~ ~192 run function cobbledomes:build/types/flying
