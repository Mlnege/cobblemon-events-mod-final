execute positioned ~96 ~ ~96 run function cobbledomes:build/types/ice
