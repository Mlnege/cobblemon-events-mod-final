execute positioned ~-96 ~ ~0 run function cobbledomes:build/types/water
